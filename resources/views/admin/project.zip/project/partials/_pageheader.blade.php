<!-- start: PAGE HEADER -->
<div class="row">
<div class="col-sm-12">

<ol class="breadcrumb">
	<li>
	<i class="clip-home-3"></i>
	<a href="#">Home</a></li>
	<li class="active">Users</li>
	<li class="active">{{ $settings_form }}</li>
	
	<!--
	<li class="search-box">
	<form class="sidebar-search">
	<div class="form-group">
	<input type="text" placeholder="Start Searching..." data-default="130">
	<button class="submit">
	<i class="clip-search-3"></i>
	</button>
	</div>
	</form>
	</li>
	-->
</ol>					

<div class="page-header">
	<h1>{{ $settings_form }}<small> Manage core config data</small></h1>
	
	<div class="row">
<div class="col-sm-10 stat-label">	
	<a href="#" class="col-sm-1 listing_stus">{{$projectStat['active']}}<br><span class="label label-success">Active</span></a>
	<a href="#" class="col-sm-1 listing_stus">{{$projectStat['inactive']}}<br><span class="label label-danger">Inactive</span></a>
	<a href="#" class="col-sm-1 listing_stus">{{$projectStat['featured']}}<br><span class="label label-warning">Featured</span></a>
	<a href="#" class="col-sm-2 listing_stus">{{$projectStat['suspend']}}<br><span class="label label-inverse">Suspended</span></a>
	<a href="#" class="col-sm-2 listing_stus">{{$projectStat['flag']}}<br><span class="label label-success">System Flagged</span></a>
	<a href="#" class="col-sm-2 listing_stus">{{$projectStat['flag']}}<br><span class="label label-danger">User Flagged</span></a>
	<a href="/admin/project"  class="col-sm-1 listing_stus">{{$projectStat['all']}}<br><span class="label label-default">All</span></a>
	
</div>

	<div class="col-sm-2 pull-right">	
		<a class="btn btn-green custom-button" href="/admin/project/create">Add Project <i class="fa fa-plus"></i></a>
	</div>	
	
	
	</div>	
	
	

	
	
	
	
	
	
	
	
	
	
	
</div>

</div>
</div>	