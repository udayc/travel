@extends('admin.layout')

@section('content')
<!-- Start: PAGE CONTENT-->
<div class="container">
<!-- start: PAGE HEADER -->
@include('admin.settings.partials._pageheader' , ['settings_form' => 'Add User'  ])
<!-- end: PAGE HEADER -->
					
<!-- Start .flash-message -->	
@include('admin.partials._flashmsg')
<!-- end .flash-message -->
@if ($errors->has())
<div class="alert alert-danger">
@foreach ($errors->all() as $error)
	{{ $error }}<br>        
@endforeach
</div>
@endif





<div class="row">
<div class="col-sm-12">

<div class="panel panel-default">
<div class="panel-heading">
<i class="fa fa-external-link-square"></i> Add Project {{ Session::get('last_insert_id') }}
</div>

<div class="panel-body">

<form class="form-horizontal" id="bookForm" role="form" name="add_project" action="/admin/project" method="POST">
<input type="hidden" name="_token" value="{{ csrf_token() }}">
<input type="hidden" name="reward_row_count" id="reward_row_count" value="0"/>
<!-- set For step -->
@include('admin.project.partials._formstep_3' , ['class' => 'selected' , 'rel'=>'1' , 'isDone' => '1' ,'skey' => Session::get('last_insert_id') ])
<!-- set For step : End  -->

		<fieldset>
			<legend>Reward</legend>	
			<div class="form-group">
			
			<div class="form-group @if ($errors->has('pledge_amount')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Pledge amount ($)
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="pledge_amount" placeholder="Enter pledge amount" name="pledge_amount[]" value="">
			</div>
			<div class="col-sm-1">
			<button type="button" class="btn btn-default addButton"><i class="fa fa-plus"></i></button>	
			</div>
			</div>			

			<div class="form-group @if ($errors->has('short_note')) has-error @endif">
			<label for="short_note" class="col-sm-2 control-label">
			Short Description
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<textarea class="form-control" name="short_note[]" placeholder="Default Text" id="short_note" rows="8"></textarea>
			</div>
			</div>

			<div class="form-group @if ($errors->has('user_limit')) has-error @endif">
			<label for="user_limit" class="col-sm-2 control-label">
			Pledge max user limit
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="number" class="form-control" id="user_limit" placeholder="Enter max user limit" name="user_limit[]" value="">
			</div>
			</div>			
			
			<div class="form-group @if ($errors->has('dob')) has-error @endif">
			<label for="dob" class="col-sm-2 control-label">
			Estimated delivery date
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9 dateContainer"><div class="input-group" >
			<input type="text" data-date-format="yyyy-mm-dd" data-date-viewmode="years" class="form-control date-picker" name="estimated_delivery[]"   value="" placeholder="Estimated delivery date">
			<span class="input-group-addon"> <i class="fa fa-calendar"></i> </span>	</div>	
			</div>
			</div>	
			
				
			
			
			
			

			<div class="form-group @if ($errors->has('pledge_amount')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Additional Information
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="shipping_details" placeholder="Enter additional info" name="shipping_details[]" value="">
			<span class="help-block"><i class="fa fa-info-circle"></i> Additional information related shipping or other stuffs</span>
			</div>
			</div>	

		</div>


		<div class="form-group hide" id="bookTemplate">
	
			<div class="form-group @if ($errors->has('pledge_amount')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Pledge amount ($)
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="pledge_amount" placeholder="Enter your valid address" name="pledge_amount[]" value="">
			</div>
			<div class="col-sm-1">
			<button type="button" class="btn btn-default removeButton"><i class="fa fa-minus"></i></button>
			</div>	
			</div>			
			
			
			
			
			
			
			
			<div class="form-group @if ($errors->has('short_note')) has-error @endif">
			<label for="short_note" class="col-sm-2 control-label">
			Short Description
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<textarea class="form-control" name="short_note[]" placeholder="Default Text" id="short_note" rows="8"></textarea>
			</div>
			</div>
			
			
			<div class="form-group @if ($errors->has('user_limit')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Pledge max user limit
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="number" class="form-control" id="user_limit" placeholder="Enter your valid address" name="user_limit[]" value="">
			</div>
			</div>			
			
			<div class="form-group @if ($errors->has('estimated_delivery')) has-error @endif">
			<label for="dob" class="col-sm-2 control-label">
			Estimated delivery date
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9 dateContainer"><div class="input-group"  >
			<input type="text"  data-date-format="yyyy-mm-dd" data-date-viewmode="years" class="form-control date-picker" name="estimated_delivery[]"  value="">
			<span class="input-group-addon"> <i class="fa fa-calendar"></i> </span>	</div>	
			</div>
			</div>	
			
		


			<div class="form-group @if ($errors->has('shipping_details')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Additional Information
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="shipping_details[]" placeholder="Enter your valid address" name="shipping_details[]" value="">
			<span class="help-block"><i class="fa fa-info-circle"></i> Additional information related shipping or other stuffs</span>
			</div>
			</div>	

		</div>
		</fieldset>									

		<fieldset>
		<legend>&nbsp;</legend>
			<div class="form-group">
			<div class="col-sm-2 col-sm-offset-2">	
			<button type="button" class="btn btn-orange" name="submit-btn" id="back-step-2" value="2" data-token="{{ csrf_token() }}" >Back</button>			
			<button type="submit" class="btn btn-orange" name="submit" value="add-user-form">Next</button>							
			</div>
			</div>										
		</fieldset>


<input type="hidden" name="step" value="3">
</form>
</div>

</div>
</div>					
</div>	




<!-- end: PAGE CONTENT-->
</div>

@stop

@include('admin.project.partials._relatedfiles')
