@extends('admin.layout')

@section('content')
<!-- Start: PAGE CONTENT-->
<div class="container">
<!-- start: PAGE HEADER -->
@include('admin.project.partials._pageheader' , ['settings_form' => 'Project Management', 'projectStat'=> $dataStat  ])
<!-- end: PAGE HEADER -->
					
<!-- Start .flash-message -->	
@include('admin.partials._flashmsg')
<!-- end .flash-message -->
<!--
<div class="row">
	<div class="col-md-12 space20" align="right">
	<a class="btn btn-green custom-button" href="/admin/user/create">Add New <i class="fa fa-plus"></i></a>
	</div>
</div>
-->	



<div class="row">
<div class="col-md-12">
		<!-- start: DYNAMIC TABLE PANEL -->
<div class="panel panel-default">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i>
				Project Lists
				<div class="panel-tools">
					<a class="btn btn-xs btn-link panel-collapse collapses" href="#"> </a>					
					<a class="btn btn-xs btn-link panel-refresh" href="#"> <i class="fa fa-refresh"></i> </a>					
					<a class="btn btn-xs btn-link panel-close" href="#"> <i class="fa fa-times"></i> </a>
				</div>
			</div>
			
		<div class="row">
				<div class="col-sm-3 col-md-3 pull-right">
				
				{!! Form::open( array( 'route'=> 'posts.search' , 'class' => 'navbar-form' ,'role' => 'search' ,'method'=>'post'  )) !!}
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term" required value=" {{ isset($searchKey) ? $searchKey : '' }} ">
						<div class="input-group-btn">
							<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
						</div>
					</div>
				{!! Form::close() !!}
				</div>		
		</div>
		
		
		
		
	<div class="panel-body">
	
		
	
	
	
	
	<div class="table-responsive">
	

	
	
	
	
	<table class="table table-bordered table-hover" id="sample-table-1">
	<thead>
	<tr>
	<th class="select dc center" rowspan="2" > 
	<label><input type="checkbox" id="check_all_nonexx" ></label>
	</th>	
	<th rowspan="2" class="center">Name</th>
	<th rowspan="2" class="center">Posted By</th>
	<th class="dc center" colspan="2">Amount</th>
	<th class="dc center" colspan="2">Site Fee</th>
	<th class="dr" rowspan="2">Funding <br>Start Date</th>
	
	<th class="dc center" colspan="3"  >Voting</th>
	<th class="dc" rowspan="2">Funding<br> End Date</th>
	<th rowspan="2">Status</th>
	<th class="dc" rowspan="2">Actions</th>
	</tr>
	<tr>
	<th class="dr center">Needed</th>
	<th class="dc">Collected($)</th>
	<th class="dr">Listing Fee</th>
	<th class="dc">Commission</th>
	<th class="dr">Total Voting</th>
	<th class="dc">Count</th>
	<th class="center">Average</th>
	</tr>
	</thead>																	
	<tbody>
	@if( $dataStat['all'] > 0 )
	
	
		@foreach($projects as $val)						
		<tr>
		<td class="center">	
				<input type="checkbox" class="ulistcheckbox" name="ulist" value="{{ $val->id }}">
		
		</td>

		<td class="span4 dl">
		@if( $val->status == 3)<i class="clip-star-3"></i> @endif {{ $val->name }}
		@if( $val->status == 2)<code> suspend </code>@endif
		@if( $val->status == 1)<code> flaged </code>@endif
		</td>
		<td class="dc">{{ $val->user()->first()->name }}</td>
		<td class="dr">{{ $val->funding_goal }}</td>
		<td class="dc">0.00</td>
		<td class="dr">0.00</td>
		<td class="dr"><span class="label label-success"><span title="Zero Dollars" class="c cr">0.00</span></span></td>
		<td class="dr"><span title="{{ $val->created_at->format('M d, Y')}}" class="c cr">{{ $val->created_at->format('M d, Y')}}</span></td>		
		<td class="dc"><span title="four" class="c">-</span></td>
		<td class="dc">	<span title="" class="c">-</span>    </td>
		<td class="dl">-</td>
		<td class="dc"><span title="{{ $val->funding_end_date}}" class="c cr">{{ date('M d, Y' , strtotime($val->funding_end_date) ) }}</span></td>
		<td class="dl">
		@if( $val->active == 0)		
		<span class="label label-sm label-danger">Pending</span>
		@else
		<span class="label label-sm label-success">Active</span>
		@endif
		</td>
		<td class="span1 dc">
			

		<div class="btn-group">
		<a class="btn btn-primary dropdown-toggle btn-sm" data-toggle="dropdown" href="#">
		<i class="fa fa-cog"></i> <span class="caret"></span>
		</a>
		<ul role="menu" class="dropdown-menu pull-right">

		<li role="presentation">
		<a role="menuitem" tabindex="-1" href="/admin/project/{{ $val->id }}">
		<i class="fa fa-share"></i> View
		</a>
		</li>
		<li role="presentation">
		<a role="menuitem" tabindex="-1" href="/admin/project">
		<i class="fa fa-edit"></i> Edit
		</a>
		</li>															
		<li role="presentation"><a class="deleteRecord" role="menuitem" tabindex="-1" href="javascript:void(0)" data-value="{{ $val->id }}"  data-token="{{ csrf_token() }}" data-url="/admin/project"><i class="fa fa-times"></i> Remove</a>
		</li>
		</ul>
		</div>
		</td>		
	</tr>
	@endforeach

	@else
	<tr><td colspan="14">No result found !</td></tr>
	@endif
	</tbody>
	
	</table>
	
<div class="row">
<div class="col-md-6">
	<div class="dataTables_info" id="sample_2_info">
	Showing <?php echo $projects->firstItem();?> - <?php echo $projects->lastItem();?>  of <?php echo $projects->total();?> entries 
	</div>
</div>	
<div class="col-md-2 pull-right">
<?php echo $projects->render(); ?>	
</div>	
</div>
		
	
	



	
	
	
	


	</div>
		
	
	
	</div>			
	
				
			
			
			

		</div>
		<!-- end: DYNAMIC TABLE PANEL -->
	</div>
</div>

	<div class="row">	
		<div class="col-md-2">
		
			<select id="UserMoreActionId" class="js-admin-index-autosubmit form-control" name="data[User][more_action_id]" data-token="{{ csrf_token() }}" data-url="/admin/project">
			<option value="">-- More actions --</option>
			<option value="1">Inactive</option>
			<option value="2">Active</option>
			<option value="3">Delete</option>
			<option value="11">Suspend</option>
			<option value="12">Featured</option>
			<option value="13">System Flag</option>
			</select>

		</div>
	</div>	









<!-- end: PAGE CONTENT-->
</div>









@stop

@section('styles')
<style>
.stat-label .label { display:block; }
.stat-label  {margin-top:-10px; }
</style>
@stop



@section('scripts')
	<script src="/plugins/bootstrap-modal/js/bootstrap-modal.js"></script>
	<script src="/plugins/bootstrap-modal/js/bootstrap-modalmanager.js"></script>
	<script src="/js/ui-modals.js"></script>
	<script src="/js/ui-customs.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				UIModals.init();
				UICustoms.init();
				
			});
		</script>

@stop