@extends('admin.layout')

@section('content')
<!-- Start: PAGE CONTENT-->
<div class="container">
<!-- start: PAGE HEADER -->
@include('admin.settings.partials._pageheader' , ['settings_form' => 'Add User'  ])
<!-- end: PAGE HEADER -->
					
<!-- Start .flash-message -->	
@include('admin.partials._flashmsg')
<!-- end .flash-message -->
@if ($errors->has())
<div class="alert alert-danger">
@foreach ($errors->all() as $error)
	{{ $error }}<br>        
@endforeach
</div>
@endif





<div class="row">
<div class="col-sm-12">

<div class="panel panel-default">
<div class="panel-heading">
<i class="fa fa-external-link-square"></i> Add Project
</div>


<div class="panel-body">
<form enctype="multipart/form-data" accept-charset="UTF-8" class="form-horizontal" role="form" name="add_user" action="/admin/project" method="POST" id="form-step-1">


<div class="errorHandler alert alert-danger no-display">
<i class="fa fa-times-sign"></i> You have some form errors. Please check below.
</div>
<div class="successHandler alert alert-success no-display">
<i class="fa fa-ok"></i> Your form validation is successful!
</div>



<input type="hidden" name="_token" value="{{ csrf_token() }}">
<input type="hidden" name="step" value="1">
@include('admin.project.partials._formstep_1' , ['class' => 'selected' , 'rel'=>'1' , 'isDone' => '1' ,'skey' => Session::get('last_insert_id') ])

		<fieldset>
			<legend>User</legend>
			<div class="form-group">
			<label for="form-field-2" class="col-sm-2 control-label">
			 Select User
			</label>
			<div class="col-sm-9">			
			{!! Form::select('user_id', $users , (empty($projectdet) ? null : $projectdet->user_id) ,  array('class' => 'form-control')) !!}			
			</div>
			</div>	

		</fieldset>			
		
		
		<fieldset>
			<legend>Basic Info</legend>	
			
			<div class="form-group @if ($errors->has('name')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			Name
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="name" placeholder="Enter project name" name="name"  value="{{ isset($projectdet->name) ? $projectdet->name : ''}}">
			</div>
			</div>
			
			<div class="form-group">
			<label for="form-field-2" class="col-sm-2 control-label">
			 Project Category
			</label>
			<div class="col-sm-9">			
			{!! Form::select('P_CAT_ID', $categories , (empty($projectdet) ? null : $projectdet->P_CAT_ID)  ,  array('class' => 'form-control')) !!}			
			</div>
			</div>

			<div class="form-group">
			<label for="form-field-2" class="col-sm-2 control-label">
			 Select Genre
			</label>
			<div class="col-sm-9">			
			{!! Form::select('project_genre_id', $genres , (empty($projectdet) ? null : $projectdet->project_genre_id)  ,  array('class' => 'form-control')) !!}			
			</div>
			</div>	


			
			
			
			
			
			
			<div class="form-group @if ($errors->has('short_description')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			Short Description
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<textarea class="form-control" name="short_description" placeholder="Default Text" id="short_description" rows="8">{{ isset($projectdet->short_description) ? $projectdet->short_description : ''}}</textarea>
			</div>
			</div>

			<div class="form-group @if ($errors->has('username')) has-error @endif">
			<label for="form-field-2" class="col-sm-2 control-label">
			Upload Image
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			
			<div class="fileupload fileupload-new" data-provides="fileupload">
				<div class="input-group">
					<div class="form-control uneditable-input">
						<i class="fa fa-file fileupload-exists"></i>
						<span class="fileupload-preview"></span>
					</div>
					<div class="input-group-btn">
						<div class="btn btn-light-grey btn-file">
							<span class="fileupload-new"><i class="fa fa-folder-open-o"></i> Select file</span>
							<span class="fileupload-exists"><i class="fa fa-folder-open-o"></i> Change</span>
							<input type="file" class="file-input" name="file_attachment">
						</div>
						<a href="#" class="btn btn-light-grey fileupload-exists" data-dismiss="fileupload">
							<i class="fa fa-times"></i> Remove
						</a>
					</div>
				</div>
				<p class="help-block">
				Only jpg , png , gif support
				</p>			
			</div>	

			</div>
			</div>
		</fieldset>									

	
		<fieldset>
			<legend>Funding</legend>

			<div class="form-group">
			<label for="form-field-2" class="col-sm-2 control-label">
			Payment Method
			</label>
			<div class="col-sm-9">			
			<select class="form-control" id="payment_method" name="payment_method">			
			<option value="Fixed Funding">Fixed Funding</option>
			</select>										
			</div>
			</div>	



			
			
			<div class="form-group @if ($errors->has('funding_goal')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Needed Amount
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="funding_goal" placeholder="Enter funding goal amount" name="funding_goal" value="{{ isset($projectdet->funding_goal) ? $projectdet->funding_goal : ''}}">
			
			<div class="checkbox">
			<label>
			<input type="checkbox" class="green" name="allow_overfunding" id="allow_overfunding" {{ isset($projectdet->allow_overfunding) ? 'checked' : ''}} >
			Allow overfunding
			</label>
			<span class="help-block"><i class="fa fa-info-circle"></i> 
			By enabling this feature, users can authenticate their account using Facebook.</span>
			</div>			
			
			
			
			</div>
			</div>
			
			
			<div class="form-group @if ($errors->has('funding_end_date')) has-error @endif">
			<label for="dob" class="col-sm-2 control-label">
			Project funding end date
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9"><div class="input-group">
			<input type="text" data-date-format="yyyy-mm-dd" data-date-viewmode="years" class="form-control date-picker" name="funding_end_date" id="funding_end_date" value="{{ isset($projectdet->funding_end_date) ? $projectdet->funding_end_date : ''}}">
			<span class="input-group-addon"> <i class="fa fa-calendar"></i> </span>	</div>	
			</div>
			</div>			
			
			
			
			
			
			

		</fieldset>		


		<fieldset>
			<legend>Websites</legend>	
			
			<div class="form-group @if ($errors->has('linkedIn_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			LinkedIn URL			
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="linkedIn_url" placeholder="Enter linkedIn url" name="linkedIn_url" value="{{ isset($projectdet->linkedIn_url) ? $projectdet->linkedIn_url : ''}}" >
			</div>
			</div>
			
			<div class="form-group @if ($errors->has('twitter_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			Twitter URL			
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="twitter_url" placeholder="Enter twitter url" name="twitter_url" value="{{ isset($projectdet->twitter_url) ? $projectdet->twitter_url : ''}}" >
			</div>
			</div>			
			
			<div class="form-group @if ($errors->has('myspace_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			MySpace URL			
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="myspace_url" placeholder="Enter myspace url " name="myspace_url" value="{{ isset($projectdet->myspace_url) ? $projectdet->myspace_url : ''}}" >
			</div>
			</div>			
			
			<div class="form-group @if ($errors->has('homepage_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			Home page URL			
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="homepage_url" placeholder="Enter homepage url" name="homepage_url" value="{{ isset($projectdet->homepage_url) ? $projectdet->homepage_url : ''}}" >
			</div>
			</div>			
			

			<div class="form-group @if ($errors->has('facebook_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			Facebook URL		
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="facebook_url" placeholder="Enter facebook url" name="facebook_url" value="{{ isset($projectdet->facebook_url) ? $projectdet->facebook_url : ''}}" >
			</div>
			</div>			
			
			<div class="form-group @if ($errors->has('imdb_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			IMDb URL			
			</label>
			<div class="col-sm-9">
			<input type="url" class="form-control" id="imdb_url" placeholder="Enter imdb url" name="imdb_url" value="{{ isset($projectdet->imdb_url) ? $projectdet->imdb_url : ''}}">
			</div>
			</div>		


		
	
		</fieldset>			
		
		
		
		
		
		
		
		
		


		<fieldset>
		<legend>&nbsp;</legend>
			<div class="form-group">
			<div class="col-sm-2 col-sm-offset-2">										
			<button type="submit" class="btn btn-orange" name="submit" value="add-user-form">Continue</button>							
			</div>
			</div>										
		</fieldset>


</form>
</div>

</div>
</div>					
</div>	




<!-- end: PAGE CONTENT-->
</div>

@stop

@include('admin.project.partials._relatedfiles')