@extends('admin.layout')

@section('content')
<!-- Start: PAGE CONTENT-->
<div class="container">
<!-- start: PAGE HEADER -->
@include('admin.settings.partials._pageheader' , ['settings_form' => 'Add User'  ])
<!-- end: PAGE HEADER -->
					
<!-- Start .flash-message -->	
@include('admin.partials._flashmsg')
<!-- end .flash-message -->
@if ($errors->has())
<div class="alert alert-danger">
@foreach ($errors->all() as $error)
	{{ $error }}<br>        
@endforeach
</div>
@endif





<div class="row">
<div class="col-sm-12">

<div class="panel panel-default">
<div class="panel-heading">
<i class="fa fa-external-link-square"></i> Add Project {{ Session::get('last_insert_id') }}
</div>

<div class="panel-body">

<form enctype="multipart/form-data" accept-charset="UTF-8" class="form-horizontal" role="form" name="add_project" action="/admin/project" method="POST" id="form-step-2" >
<input type="hidden" name="_token" value="{{ csrf_token() }}">

<div class="errorHandler alert alert-danger no-display">
<i class="fa fa-times-sign"></i> You have some form errors. Please check below.
</div>
<div class="successHandler alert alert-success no-display">
<i class="fa fa-ok"></i> Your form validation is successful!
</div>




<!-- set For step -->
@include('admin.project.partials._formstep_2' , ['class' => 'selected' , 'rel'=>'1' , 'isDone' => '1' ,'skey' => Session::get('last_insert_id') ])
<!-- set For step : End  -->

		<fieldset>
			<legend>Project Details</legend>	
			<div class="form-group @if ($errors->has('details_description')) has-error @endif">
			<label for="details_description" class="col-sm-2 control-label">
			Short Description
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<textarea class="form-control" name="details_description" placeholder="Default Text" id="details_description" rows="8">{{ isset($projectdet->details_description) ? $projectdet->details_description : ''}}</textarea>
			</div>
			</div>
		</fieldset>									

	
		<fieldset>
			<legend>Location</legend>
			
			<div class="form-group @if ($errors->has('address')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Address
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="address" placeholder="Enter your valid address" name="address" value="{{ isset($projectdet->address) ? $projectdet->address : ''}}">
			</div>
			</div>
			
			<div class="form-group @if ($errors->has('address_alternate')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			Address(Optional)
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="address_alternate" placeholder="Enter your alternate address" name="address_alternate" value="{{ isset($projectdet->address_alternate) ? $projectdet->address_alternate : ''}}">
			</div>
			</div>			
			
			<div class="form-group @if ($errors->has('funding_goal')) has-error @endif">
			<label for="website" class="col-sm-2 control-label">
			City
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="city" placeholder="Enter city" name="city" value="{{ isset($projectdet->city) ? $projectdet->city : ''}}">
			</div>
			</div>				
			
			<div class="form-group @if ($errors->has('state')) has-error @endif">
			<label for="state" class="col-sm-2 control-label">
			State
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="state" placeholder="Enter state" name="state" value="{{ isset($projectdet->state) ? $projectdet->state : ''}}">
			</div>
			</div>				
			
			
			<div class="form-group @if ($errors->has('country')) has-error @endif">
			<label for="country" class="col-sm-2 control-label">
			Country
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			{!! Form::select('country_id', $countries , (empty($projectdet) ? null : $projectdet->country_id) , array('class' => 'form-control'))  !!}
			</div>
			</div>				
			
			<div class="form-group @if ($errors->has('pincode')) has-error @endif">
			<label for="pincode" class="col-sm-2 control-label">
			Pincode
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="pincode" placeholder="Enter pincodex" name="pincode" value="{{ isset($projectdet->pincode) ? $projectdet->pincode : ''}} ">
			</div>
			</div>				
	

		</fieldset>		


		<fieldset>
			<legend>Project Updates</legend>	
			
			<div class="form-group @if ($errors->has('feed_url')) has-error @endif">
			<label for="feed_url" class="col-sm-2 control-label">
			Feed URL
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="feed_url" placeholder="Enter feed_url" name="feed_url"  value="{{ isset($projectdet->feed_url) ? $projectdet->feed_url : ''}} ">
			<span class="help-block"><i class="fa fa-info-circle"></i> Automatically fetch update from the given feed url.</span>
			</div>
			</div>

		</fieldset>			
		
		
		<fieldset>
			<legend>Video Url</legend>	
			
			<div class="form-group @if ($errors->has('external_video_url')) has-error @endif">
			<label for="form-field-1" class="col-sm-2 control-label">
			Video URL
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="external_video_url" placeholder="Enter external video url" name="external_video_url" value="{{ isset($projectdet->external_video_url) ? $projectdet->external_video_url : ''}}" >
			<span class="help-block"><i class="fa fa-info-circle"></i> External video url like youtube etc.</span>
			</div>
			</div>

		</fieldset>				
		
		
		<fieldset>
			<legend>Media Files</legend>	
			
			<div class="form-group @if ($errors->has('media_file_attachment')) has-error @endif">
			<label for="form-field-2" class="col-sm-2 control-label">
			Upload Image
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			
			<div class="fileupload fileupload-new" data-provides="fileupload">
				<div class="input-group">
					<div class="form-control uneditable-input">
						<i class="fa fa-file fileupload-exists"></i>
						<span class="fileupload-preview"></span>
					</div>
					<div class="input-group-btn">
						<div class="btn btn-light-grey btn-file">
							<span class="fileupload-new"><i class="fa fa-folder-open-o"></i> Select file</span>
							<span class="fileupload-exists"><i class="fa fa-folder-open-o"></i> Change</span>
							<input type="file" class="file-input" name="media_file_attachment">
						</div>
						<a href="#" class="btn btn-light-grey fileupload-exists" data-dismiss="fileupload">
							<i class="fa fa-times"></i> Remove
						</a>
					</div>
				</div>
				<p class="help-block">
				You can add files related to this project. The file type can be jpg, jpeg, png, gif, doc, xls, txt, wmv, flv or pdf. 
				</p>			
				
				
			</div>	
			</div>
			</div>

			
			<div class="form-group @if ($errors->has('media_file_short_note')) has-error @endif">
			<label for="media_file_short_note" class="col-sm-2 control-label">
			Short Note 
			<span class="symbol required"></span>
			</label>
			<div class="col-sm-9">
			<input type="text" class="form-control" id="media_file_short_note" placeholder="Short note about media file" name="media_file_short_note" value="{{ isset($projectdet->media_file_short_note) ? $projectdet->media_file_short_note : ''}}" >
			<span class="help-block"><i class="fa fa-info-circle"></i> Write down short note about media file.</span>
			</div>
			</div>			

		</fieldset>			
		
		
		


		<fieldset>
		<legend>&nbsp;</legend>
			<div class="form-group">
			<div class="col-sm-2 col-sm-offset-2">
			<button type="button" class="btn btn-orange" name="submit-btn" id="back-step-2" value="1" data-token="{{ csrf_token() }}" >Back</button>			
			<button type="submit" class="btn btn-orange" name="submit" value="add-user-form">Continue</button>							
			</div>
			</div>										
		</fieldset>


<input type="hidden" name="step" value="2">
</form>
</div>

</div>
</div>					
</div>	




<!-- end: PAGE CONTENT-->
</div>

@stop

@include('admin.project.partials._relatedfiles')